package com.hbb.video;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.regex.Pattern;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.File;

public class VideoMain {

	public static void main(String[] args) {
		LineNumberReader  lnrO = null;
		LineNumberReader  lnrN = null;
		String path = "/Users/HopeBayBridge/Documents/VideoDownloader/src/";  // 文件目录
		String tmpPath = path + "video.temp.srt";      // google 不正确的文件内容
		String desPath = path +"video.aerniya.srt";   // 目标文件
		try {
			lnrO =  new LineNumberReader(new InputStreamReader(new FileInputStream(path + "video.zh-cn.srt"),"utf-8"));
		    lnrN =  new LineNumberReader(new InputStreamReader(new FileInputStream(tmpPath),"utf-8"));
			String bO="";
			String bN="";
		
			StringBuffer sb = new StringBuffer();
			try {
				while((bO = lnrO.readLine())!=null && (bN = lnrN.readLine())!=null && lnrO.getLineNumber() == lnrN.getLineNumber()){
					//System.out.println(bO +"---" + lnrO.getLineNumber() + "---:" + bN +"---" + );
					
				   // if(Pattern.matches(".*[A-Za-z]+.*", bO)) {
					if(Pattern.matches("^-?\\d+(\\.\\d+)?$", bO) || bO.contains("-->") || bO.trim().equals("") || null == bO.trim()) {	
						sb.append(bO+"\r\n");
				    }else {
				    	sb.append(bN+"\r\n");
				    }
				   
				}
				
				System.out.println(sb.toString());
				
				BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(desPath),"utf-8"));
				bw.write(sb.toString());
				bw.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (UnsupportedEncodingException | FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				lnrO.close();
				lnrN.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


	}

}
